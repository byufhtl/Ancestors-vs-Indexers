/**
 * Created by calvinmcm on 6/28/16.
 */

define([],function(){

    function Point(x,y){
        this.X = x;
        this.Y = y;
    }

    return Point;
});